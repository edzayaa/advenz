
(function() {

	'use strict';

	angular
		.module('app')
		.controller('homeController', homeController);

	function homeController($scope, $location, assetss, Notification) {


		$scope.mostrarSlider=true;
		angular.extend($scope, {
			verProd:verProd,
			enviarCoti:enviarCoti,
			goTienda: goTienda,
			goContacto: goContacto,
			goCarrito: goCarrito,
			goNosotros: goNosotros,
			enviarContacto: enviarContacto, 
			goProductoBuscar:goProductoBuscar,
			goHome: goHome,
			registerCliente: registerCliente,
			loguearCliente:loguearCliente,
			limpiar: limpiar,
			salirOut:salirOut,
			register:register,
			registerModal: registerModal,
			login:login,
			aggCart: aggCart,
			pedir: pedir,
			pedirModal:pedirModal,
			verCarrito: verCarrito,
			verCarritoModal:verCarritoModal,
			ejecutarPago:ejecutarPago,
			borrarItemCart:borrarItemCart,
			getVentasUser:getVentasUser,
			detalleVentasUser:detalleVentasUser,
			carritoMovil: carritoMovil,
			userMovil: userMovil,
			loginModal:loginModal,
			salirOutModal:salirOutModal
		});		
		
		$scope.prodsCart = [];
		$scope.imagenUrl = 'https://worldfurniturepanama.com/tiendaBackPana/Prods/'

		if (localStorage.getItem("prodsCart")) {
			$scope.prodsCart = JSON.parse(localStorage.getItem("prodsCart"));
		}else{
			$scope.prodsCart = [];
		}


		function enviarCoti(contac){

			console.log(contac);
			console.log($scope.prodsCart);

			assetss.enviarCoti(contac, $scope.prodsCart).then(function(res)
			{
				if (res.data.code == 200) {
					Notification.info("Se ha enviado su mensaje");
				
				}else{
					Notification.error("Se ha enviado su mensaje");
				
				}

			})	
		}

		function registerCliente(command){
			
			assetss.registerCliente(command).then(function(res)
			{
				if (res.data.code == 200) {
					$scope.mensajeRegistroGood=true;
				}else{
					$scope.mensajeRegistroFail=true;
				}

				console.log(res.data);
			})
			
		}
		function getBank(){
			
			assetss.getBank().then(function(res)
			{
				if (res.data.code == 200) {
					console.log(res.data.response.productos);
					$scope.bancos = res.data.response.productos;
				}else{
					console.log(res.data);
				}

				console.log(res.data);
			})
			
		}

		function getPorductoDestacados(){
			
			assetss.getPorductoDestacados().then(function(res)
			{
				if (res.data.code == 200) {
					$scope.prodDesta = res.data.response.productosDestacados;
				}else{
					console.log(res.data);
				}
			})
			
		}
		function getVentasUser(){
			localStorage.removeItem("prodsCart");

			$scope.mostrarSlider=false;
			assetss.getVentasUser().then(function(res)
			{
				if (res.data.code == 200) {
					$scope.ventas = res.data.response.ventas;
				}else{
					console.log(res.data);
				}
			})
			
		}
		function detalleVentasUser (reference){
			
			
			
			assetss.getDetalleVentasUser(reference).then(function(res)
			{
				if (res.data.code == 200) {
					$scope.detalles = res.data.response.detalles;
					$('#detalleModal').modal();
				}else{
					console.log(res.data);
				}
			})
			
		}
		

		function ejecutarPago(command){
			console.log(command);

			assetss.ejecutarPago(command, $scope.total).then(function(res)
			{
				if (res.data.code == 200) {
					console.log(res.data.response);

					$scope.url = res.data.response;

					 window.location=$scope.url;

				}else{
					console.log('Error');
				}

				console.log(res.data);
			})
			
		}

		
		function loguearCliente(command){

			console.log(command);
			assetss.loguearCliente(command).then(function(res)
			{
				if (res.data.code == 200) {
					$scope.mensajeLogueoGood=true;
					localStorage.setItem('user', res.data.response.nombre);
					localStorage.setItem('cod', res.data.response.cod);
					$scope.userSystem = localStorage.getItem("user");  
					setTimeout(function() {
		    			$location.url('/tienda');
		    			$('.login-area').fadeOut();
		            }, 3000);
			
				}else{
					$scope.mensajeLogueoFail=true;
				}

				//$scope.gale = res.data.response.register;
				console.log(res.data);
			})
		}

		function goProductoBuscar(nombre){
			$scope.mostrarSlider=false;
			
			assetss.getPorductoBuscado(nombre).then(function(res)
			{
				if (res.data.code == 200) {
					$scope.productos = res.data.response.productos;
					$location.url('/tienda');
				}

				//$scope.gale = res.data.response.register;
				console.log(res.data);
			})
		}

		function goTienda(codSubCategoria){
			$scope.mostrarSlider=false;
			console.log(codSubCategoria);
			$location.url('/tienda');
			assetss.getPorductoSubCat(codSubCategoria).then(function(res)
			{
				if (res.data.code == 200) {
					$scope.productos = res.data.response.productos;
			
				}else{
					$scope.mensajeLogueoFail=true;
				}

				//$scope.gale = res.data.response.register;
				console.log(res.data);
			})			
		}

		function verProd(prod){
			$scope.mostrarSlider=false;		
			$location.url('/prod');	
			$scope.producto = prod;
			console.log(prod);
		}		

		function goContacto(){
			$scope.mostrarSlider=false;		
			$location.url('/contacto');	
		}

		function goCarrito(){
			$scope.mostrarSlider=false;		
			$location.url('/carrito');	
		}

		

		function goNosotros(){
			$scope.mostrarSlider=false;		
			$location.url('/Nosotros');	
		}

		function enviarContacto (command){
			assetss.enviarContacto(command).then(function(res)
			{
				if (res.data.code == 200) {
					Notification.info("Se ha enviado su mensaje");
				}else{
					Notification.error("Ocurrio un error");
				}

				//$scope.gale = res.data.response.register;
				console.log(res.data);
			})
		}
		

		function goHome(){
			$scope.mostrarSlider=true;
			$location.url('/');
			getPorductoDestacados();
			
		}

		function salirOut (){
			localStorage.clear();
			$location.url('/');
			/*FALTA REFRESCAR PAGINA */
			limpiar();
			Notification.info("Se ha cerrado su sesión");
		}

		function salirOutModal (){
			$('#userMobil').modal('toggle');
			localStorage.clear();
			$location.url('/');
			/*FALTA REFRESCAR PAGINA */
			limpiar();
			Notification.info("Se ha cerrado su sesión");
		}

		function register (){
			$('.register-area').fadeIn();
		}

		function registerModal (){
			$('#userMobil').modal('toggle');
			$('.register-area').fadeIn();
		}

		function login (){
			$('.login-area').fadeIn();
		}
		function loginModal (){
			$('#userMobil').modal('toggle');
			$('.login-area').fadeIn();
		}

		function aggCart(prod, cantidad){
			
			if ($scope.prodsCart == null) {
				$scope.prodsCart=[];
			}
			var bandera = true;
			console.log(prod);

			for(var i = 0; i < $scope.prodsCart.length; i++) {
			    if ($scope.prodsCart[i].cod== prod.cod) {
			        //$scope.prodsCart.splice(i, 1);
					var cant = $scope.prodsCart[i].cant + 1

					$scope.prodsCart[i].cant = cant;
					$scope.prodsCart[i].precio = parseInt($scope.prodsCart[i].precio) + parseInt(prod.precio);
					localStorage.setItem("prodsCart", JSON.stringify($scope.prodsCart));
			        total();
					Notification.info("Se agrego al articulo ya seleccionado");
			    	var bandera = false;
			    }
			}    

		    if (bandera) {
		    	var bandera = false;
		    	prod.cant = 1;
		    	$scope.prodsCart.push(prod);
				localStorage.setItem("prodsCart", JSON.stringify($scope.prodsCart));
		        console.log($scope.total);
		        total();
		        Notification.info("El articulo se agrego Exitosamente");
		    }
			
			
			if ($scope.prodsCart.length == 0) {

				$scope.prodsCart.push(prod);
				localStorage.setItem("prodsCart", JSON.stringify($scope.prodsCart));
		        console.log($scope.total);
		        total();
		        Notification.info("El articulo se agrego Exitosamente");

			}

			
		}

		function total(){
			console.log($scope.prodsCart);
			if ($scope.prodsCart){
				$scope.countCart = $scope.prodsCart.length;
				$scope.total = 0;
				$scope.prodsCart.forEach(function(index){
					$scope.total = $scope.total + parseInt(index.precio); 
				})
			} else{
				console.log('no pasa');
			}	
		}

		
		function userMovil() {

			$('#userMobil').modal();
		
		}

		function carritoMovil() {

			$('#carritoMobil').modal();
		
		}

		function pedir() {


			if (!localStorage.getItem("user")) {
				$scope.mostrarSlider=false;
				$scope.logueoMsj = true;
				$location.url('/checkout');		
			}else{
				getBank();
				$('#exampleModal').modal();
			}
		}

		function pedirModal() {

			if (!localStorage.getItem("user")) {
				$scope.logueoMsj = true;
				//$location.url('/checkout');		
			}else{
				$('#carritoMobil').modal('toggle');
				getBank();
				$('#exampleModal').modal();
			}
		}

		function verCarrito (){
			$scope.mostrarSlider=false;
			$location.url('/carrito');
			/*FALTA REFRESCAR PAGINA */
		}

		function verCarritoModal (){
			$('#carritoMobil').modal('toggle');
			$scope.mostrarSlider=false;
			$location.url('/carrito');
			/*FALTA REFRESCAR PAGINA */
		}



		function limpiar(){
			$scope.command={};
			$scope.mensajeRegistroGood=false;
			$scope.mensajeRegistroFail=false;
			$scope.mensajeLogueoGood=false;
			$scope.mensajeLogueoFail=false;
			$scope.logueoMsj = false;	
			$scope.userSystem = localStorage.getItem("user");
			console.log($scope.userSystem);
		}

		function borrarItemCart(cod){

			$scope.prodsCart = JSON.parse(localStorage.getItem("prodsCart"));

			for(var i = 0; i < $scope.prodsCart.length; i++) {
			    if ($scope.prodsCart[i].cod== cod) {
			        $scope.prodsCart.splice(i, 1);  
			    }
			}
			
			localStorage.setItem("prodsCart", JSON.stringify($scope.prodsCart));
	       	total();

	       	Notification.error("Se ha borrado el articulo");
		}

		limpiar();
		total();
		getPorductoDestacados();
		


	}

})();

