(function() {
	
	'use strict';

	angular
		.module('app')
		.service('assetss', assetss);

	function assetss($http, $q) {

		this.registerCliente = function(command)
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			formData.append("nombre", command.nombre);
			formData.append("correo", command.correo);
			formData.append("password", command.password);
			console.log(formData);
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/auth/registroCliente", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}

		this.loguearCliente = function(command)
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			formData.append("correo", command.correo);
			formData.append("password", command.password);
			console.log(formData);
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/auth/loguearCliente", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}

		this.getPorductoSubCat = function(codSubCategoria)
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			formData.append("codSubCategoria", codSubCategoria);
			console.log(formData);
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/producto/getProductoSubCategoria", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}

		this.getPorductoDestacados = function()
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/producto/getProductoDestacados", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}		

		this.getBank = function()
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/pagos/getBank", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}

		this.getVentasUser = function()
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			var codUser = JSON.parse(localStorage.getItem("cod"));
			formData.append("codUser", codUser);
			
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/pagos/getVentas", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}
		this.getDetalleVentasUser  = function(reference)
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			var codUser = JSON.parse(localStorage.getItem("cod"));
			formData.append("reference", reference);
			
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/pagos/getDetalleVentas", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}

		

		

		this.ejecutarPago = function(command, total)
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			var prods = JSON.parse(localStorage.getItem("prodsCart"));
			var codUser = JSON.parse(localStorage.getItem("cod"));
			prods = JSON.stringify(prods);
			formData.append("prods", prods);
			formData.append("codUser", codUser);
			formData.append("codBank", command.codBank);
			formData.append("nombre", command.nombre);
			formData.append("email", command.email);
			formData.append("tipoPersona", command.tipoPersona);
			formData.append("tipoIdentificacion", command.tipoIdentificacion);
			formData.append("DNI", command.DNI);
			formData.append("monto", total);
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/pagos/ejegutarPago", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}

		this.getPorductoBuscado = function(nombre)
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			formData.append("nombreProducto", nombre);
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/producto/productoBuscados", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}
		
		
		this.enviarContacto = function(command)
		{	
			var deferred = $q.defer();
			var formData = new FormData();
			formData.append("nombres", command.nombres);
			formData.append("tlf", command.tlf);
			formData.append("correo", command.correo);
			formData.append("mensaje", command.mensaje);
			console.log(formData);
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/correo/formContacDeportivo", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}

		this.enviarCoti = function(command, arreglo)
		{	
			console.log(command);
			console.log(arreglo);

			var deferred = $q.defer();
			var formData = new FormData();
			formData.append("nombres", command.nombres);
			formData.append("tlf", command.tlf);
			formData.append("correo", command.correo);
			formData.append("mensaje", command.mensaje);
			console.log(formData);
			return $http.post("https://worldfurniturepanama.com/tiendaBackPana/index.php/correo/formContacDeportivo", formData, {
				headers: {
					"Content-type": undefined
				},
				transformRequest: angular.identity
			})
			.success(function(res)
			{
				deferred.resolve(res);
			})
			.error(function(msg, code)
			{
				deferred.reject(msg);
			})
			return deferred.promise;
		}


	}

})();