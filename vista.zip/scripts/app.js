(function ()
{
    'use strict';

    angular
        .module('app',
            [
                'ngRoute','ui-notification', 'ngSanitize', 'pdfjsViewer'
            ]);
})();


